import React from 'react'
import Form3 from './Form3'
import Nav from './Nav'


const EmployeeMaster = () => {
  return (
    <div>
        <Nav/>
        <br />
        <Form3/>
    </div>
  )
}

export default EmployeeMaster