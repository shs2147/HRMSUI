import React from 'react'

function BasicInformation() {
  return (
    <div>BasicInformation</div>
  )
}

export default BasicInformation