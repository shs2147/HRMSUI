import React from 'react'

import Form from './Form'


function AddJobTitle() {
  return (
    <div xs={6}>
      <Form/>
     
    </div>
  )
}

export default AddJobTitle