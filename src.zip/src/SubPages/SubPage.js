import React from 'react'

function SubPage() {
  return (
    <div>SubPage</div>
  )
}

export default SubPage