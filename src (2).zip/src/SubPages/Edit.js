import React from 'react'

function Edit() {
  return (
    <div>Edit
    <div>
        <a href='/Shift Management/View Employee Shift'>back</a>
    </div></div>
  )
}

export default Edit